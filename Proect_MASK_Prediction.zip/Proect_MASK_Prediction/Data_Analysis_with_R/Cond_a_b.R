# Load necessary libraries
library(lme4)
library(lmerTest)
library(tidyverse)
library(ggplot2)

# Read your CSV
df <- read.csv("/Users/pablo/Coursework_SEM_2/Computational Approach to Meaning/Project_Dataset_Code/arg_nonarg_probabilities_3.csv")

# Keep only conditions 'a' and 'b'
df_ab <- df %>% filter(condition %in% c("a", "b"))

# Convert to factor
df_ab$condition <- factor(df_ab$condition)

# Set 'b' as the baseline
df_ab$condition <- relevel(df_ab$condition, ref = "b")

# Make sure item is a factor
df_ab$item <- factor(df_ab$item)

# Fit linear mixed effects model for arg_prb
model_arg <- lmer(arg_prb ~ condition + (1 | item), data = df_ab)
summary(model_arg)

# Fit model for nonarg_prb if needed
model_nonarg <- lmer(nonarg_prb ~ condition + (1 | item), data = df_ab)
summary(model_nonarg)

# Optional: Visualize
ggplot(df_ab, aes(x = condition, y = arg_prb)) +
  stat_summary(fun = mean, geom = "bar", fill = "tomato", alpha = 0.7) +
  stat_summary(fun.data = mean_cl_normal, geom = "errorbar", width = 0.2) +
  labs(title = "Mean Argument Probability: Condition a vs b",
       y = "arg_prb", x = "Condition") +
  theme_minimal()

