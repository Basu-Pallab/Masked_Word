# Load required libraries
library(lme4)
library(lmerTest)
library(tidyverse)
library(ggplot2)
# Read the CSV
df <- read.csv("/Users/pablo/Coursework_SEM_2/Computational Approach to Meaning/Project_Dataset_Code/arg_nonarg_probabilities_3.csv")


# Filter for conditions c and d
df_cd <- df %>% filter(condition %in% c("c", "d"))

# Convert condition to factor and set 'c' as the baseline
df_cd$condition <- factor(df_cd$condition)


df_cd$condition <- relevel(df_cd$condition, ref = "d")

# Ensure item is treated as a factor
df_cd$item <- factor(df_cd$item)

# Fit linear mixed-effects model for argument probability
model_arg_cd <- lmer(arg_prb ~ condition + (1 | item), data = df_cd)
summary(model_arg_cd)

# Optional: Model for non-argument probability
model_nonarg_cd <- lmer(nonarg_prb ~ condition + (1 | item), data = df_cd)
summary(model_nonarg_cd)

# Optional visualization
ggplot(df_cd, aes(x = condition, y = arg_prb)) +
  stat_summary(fun = mean, geom = "bar", fill = "steelblue", alpha = 0.7) +
  stat_summary(fun.data = mean_cl_normal, geom = "errorbar", width = 0.2) +
  labs(title = "Mean Argument Probability: Condition c vs d",
       y = "arg_prb", x = "Condition") +
  theme_minimal()

